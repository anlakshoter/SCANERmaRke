# Albion Market Pro Scanner

Веб-приложение для анализа рынка Albion Online.

## Запуск локально
1. Скачай или клонируй репозиторий.
2. Открой `index.html` в браузере.
   - или подними сервер:
     ```bash
     python -m http.server 8080
     ```
     и зайди на http://localhost:8080

## Деплой на GitHub Pages
1. Залей репозиторий на GitHub.
2. Включи GitHub Pages в Settings → Pages.
3. Выбирай branch: `main`, folder: `/ (root)`.
4. Сайт будет доступен по адресу:
   ```
   https://<твой-логин>.github.io/albion-market-scanner/
   ```
